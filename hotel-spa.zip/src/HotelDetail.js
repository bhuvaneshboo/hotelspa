import React from "react";
import { useParams, Link } from "react-router-dom";
import hotels from "./data";

const HotelDetail = () => {
  const { id } = useParams();
  const hotel = hotels.find((h) => h.id === parseInt(id));

  if (!hotel) {
    return <div>Hotel not found</div>;
  }

  return (
    <div style={{ padding: "20px" }}>
      <h1>{hotel.name}</h1>
      <img
        src={hotel.imageUrl}
        alt={hotel.name}
        style={{ width: "300px", borderRadius: "8px" }}
      />
      <p>
        <strong>Location:</strong> {hotel.location}
      </p>
      <p>
        <strong>Rating:</strong> {hotel.rating}
      </p>
      <p>
        <strong>Board Basis:</strong> {hotel.boardBasis}
      </p>
      <p>
        <strong>Dates of Travel:</strong> {hotel.datesOfTravel.join(" - ")}
      </p>
      <h3>Rooms Available</h3>
      <ul>
        {hotel.rooms.map((room, index) => (
          <li key={index}>
            {room.roomType}: {room.amount}
          </li>
        ))}
      </ul>
      <Link to="/">Back to Listings</Link>
    </div>
  );
};

export default HotelDetail;
