import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import hotels from "./data";

const App = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
   
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return <div>Loading hotels...</div>;
  }

  return (
    <div style={{ padding: "20px" }}>
      <h1>Hotel Listings</h1>
      <ul style={{ listStyleType: "none", padding: 0 }}>
        {hotels.map((hotel) => (
          <li key={hotel.id} style={{ marginBottom: "20px" }}>
            <div style={{ display: "flex", alignItems: "center" }}>
              <img
                src={hotel.imageUrl}
                alt={hotel.name}
                style={{
                  width: "100px",
                  height: "100px",
                  marginRight: "20px",
                  borderRadius: "8px",
                }}
              />
              <div>
                <h2>{hotel.name}</h2>
                <p>{hotel.location}</p>
                <p>Rating: {hotel.rating}</p>
                <Link to={`/hotel/${hotel.id}`}>View Details</Link>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
